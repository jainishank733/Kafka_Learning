package com.deliveryboy.config;

public class AppConstants {
	
	public static final String LOCATION_TOPIC_NAME = "location-update-topic";

}
